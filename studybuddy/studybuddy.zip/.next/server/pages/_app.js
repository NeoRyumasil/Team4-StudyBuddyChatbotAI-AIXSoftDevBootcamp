var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__33a51c39._.js")
R.m("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/app.js [ssr] (ecmascript)").exports
