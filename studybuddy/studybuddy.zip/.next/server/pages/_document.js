var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/bd54d__pnpm_a7159e09._.js")
R.c("server/chunks/ssr/[root-of-the-server]__fa248b9f._.js")
R.m("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/document.js [ssr] (ecmascript)").exports
