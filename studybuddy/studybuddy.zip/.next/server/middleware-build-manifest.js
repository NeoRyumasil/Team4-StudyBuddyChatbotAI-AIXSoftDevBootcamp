globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/1365e_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_76ac2649._.js",
    "static/chunks/1365e_next_dist_compiled_react-dom_e3801902._.js",
    "static/chunks/1365e_next_dist_compiled_next-devtools_index_bcc0a00f.js",
    "static/chunks/1365e_next_dist_compiled_632c2c03._.js",
    "static/chunks/1365e_next_dist_client_32793aa9._.js",
    "static/chunks/1365e_next_dist_de4883a6._.js",
    "static/chunks/c3895_@swc_helpers_cjs_6ac9f14c._.js",
    "static/chunks/StudyBuddy_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_a0ff3932._.js",
    "static/chunks/7dc55_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_e037f1f5._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];