module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/store/chatStore.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// store/chatStore.ts
__turbopack_context__.s([
    "useChatStore",
    ()=>useChatStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
const useChatStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        messages: [],
        chats: [],
        currentChatId: null,
        isLoading: false,
        setMessages: (messages)=>set({
                messages
            }),
        addMessage: (role, content)=>set((state)=>({
                    messages: [
                        ...state.messages,
                        {
                            role,
                            content,
                            created_at: new Date().toISOString()
                        }
                    ]
                })),
        setChats: (chats)=>set({
                chats
            }),
        setCurrentChatId: (chatId)=>set({
                currentChatId: chatId
            }),
        setLoading: (loading)=>set({
                isLoading: loading
            }),
        createNewChat: async (title = 'Chat Baru')=>{
            try {
                const res = await fetch('/api/chat/create', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        title
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Reload chats setelah membuat chat baru
                    await get().loadChats();
                    return data.chatId;
                }
                return null;
            } catch (error) {
                console.error('Error creating chat:', error);
                return null;
            }
        },
        loadMessages: async (chatId)=>{
            set({
                isLoading: true
            });
            try {
                const res = await fetch(`/api/chat/${chatId}/messages`);
                const data = await res.json();
                if (res.ok) {
                    // Transform data dari database ke format yang digunakan di UI
                    const messages = data.messages.map((msg)=>({
                            id: msg.id,
                            role: msg.role,
                            content: msg.content,
                            created_at: msg.created_at
                        }));
                    set({
                        messages,
                        currentChatId: chatId
                    });
                }
            } catch (error) {
                console.error('Error loading messages:', error);
            } finally{
                set({
                    isLoading: false
                });
            }
        },
        loadChats: async ()=>{
            try {
                const res = await fetch('/api/chat/list');
                const data = await res.json();
                if (res.ok) {
                    set({
                        chats: data.chats
                    });
                }
            } catch (error) {
                console.error('Error loading chats:', error);
            }
        },
        sendMessage: async (message, chatId)=>{
            // Tambahkan pesan user ke UI secara optimistic
            get().addMessage('user', message);
            try {
                const res = await fetch('/api/chat/gemini', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        message,
                        chatId
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Tambahkan response AI ke UI
                    get().addMessage('ai', data.reply);
                    // Reload chats untuk update last message
                    await get().loadChats();
                } else {
                    get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
                }
            } catch (error) {
                console.error('Error sending message:', error);
                get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
            }
        }
    }));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/store/chatStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/@radix-ui/react-separator/dist/index.mjs [app-ssr] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module 'react-markdown'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module 'remark-gfm'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
"use client";
;
;
;
;
;
;
;
function Page() {
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [educationLevel, setEducationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("SD");
    const { messages, chats, currentChatId, isLoading, loadMessages, loadChats, createNewChat, sendMessage, setCurrentChatId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useChatStore"])();
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Load chats saat komponen pertama kali dimuat
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        loadChats();
    }, [
        loadChats
    ]);
    // Auto scroll ke bawah saat ada pesan baru
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [
        messages
    ]);
    const handleSendMessage = async ()=>{
        if (!input.trim()) return;
        let chatId = currentChatId;
        // Jika belum ada chat yang aktif, wajib membuat/ memilih chat terlebih dahulu
        if (!chatId) {
            alert('Pilih atau buat chat terlebih dahulu');
            return;
        }
        // Tambahkan prefix level pendidikan ke pesan
        const educationPrefix = educationLevel ? `[Halo, aku di tingkat: ${educationLevel}]\n` : '';
        const messageWithEducation = educationPrefix + input;
        await sendMessage(messageWithEducation, chatId);
        setInput("");
    };
    const handleSelectChat = async (chatId)=>{
        setCurrentChatId(chatId);
        await loadMessages(chatId);
    };
    const handleNewChat = async ()=>{
        const chatId = await createNewChat();
        if (chatId) {
            setCurrentChatId(chatId);
            // Clear messages untuk chat baru
            __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useChatStore"].setState({
                messages: []
            });
        }
    };
    const handleQuickMessage = async (message)=>{
        if (!currentChatId) {
            alert('Pilih atau buat chat terlebih dahulu');
            return;
        }
        // Tambahkan prefix level pendidikan ke pesan
        const educationPrefix = educationLevel ? `[Halo, aku di tingkat: ${educationLevel}]\n` : '';
        const messageWithEducation = educationPrefix + message;
        await sendMessage(messageWithEducation, currentChatId);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex w-full h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-64 border-r bg-gray-50 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-3 border-b",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleNewChat,
                            className: "w-full px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 text-sm",
                            children: "+ Chat Baru"
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                            lineNumber: 91,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                            className: "h-full w-full p-2",
                            children: chats.map((chat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    onClick: ()=>handleSelectChat(chat.id),
                                    className: `p-3 mb-2 rounded-lg cursor-pointer text-sm hover:bg-gray-100 ${currentChatId === chat.id ? 'bg-gray-200' : ''}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium truncate",
                                            children: chat.title
                                        }, void 0, false, {
                                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                            lineNumber: 109,
                                            columnNumber: 17
                                        }, this),
                                        chat.last_message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500 text-xs mt-1 truncate",
                                            children: chat.last_message
                                        }, void 0, false, {
                                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                            lineNumber: 111,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, chat.id, true, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 102,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between p-3 border-b",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/logo SB.png",
                                        alt: "StudyBuddy Logo",
                                        className: "h-9 w-11"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 126,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-blue-600",
                                        children: "StudyBuddy"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 127,
                                        columnNumber: 7
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 125,
                                columnNumber: 5
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: educationLevel,
                                onChange: (e)=>setEducationLevel(e.target.value),
                                className: "border rounded-md px-2 py-1 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SD",
                                        children: "SD"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 136,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SMP",
                                        children: "SMP"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SMA",
                                        children: "SMA"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 138,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "Kuliah",
                                        children: "Kuliah"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 139,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 131,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "flex-1 overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                                ref: scrollRef,
                                className: "h-full w-full p-4 space-y-3",
                                style: {
                                    height: "100%"
                                },
                                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center text-gray-500",
                                    children: "Loading..."
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 151,
                                    columnNumber: 15
                                }, this) : messages.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center text-gray-500 mt-8",
                                    children: currentChatId ? "Belum ada pesan. Mulai percakapan!" : "Pilih chat atau buat chat baru untuk memulai"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 153,
                                    columnNumber: 15
                                }, this) : messages.map((msg, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `my-3 max-w-[80%] ${msg.role === "user" ? "ml-auto" : "mr-auto"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `text-md font-medium mb-1 ${msg.role === "user" ? "text-right text-blue-600" : "text-left text-gray-600"}`,
                                                children: msg.role === "user" ? "User" : "StudyBot"
                                            }, void 0, false, {
                                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                lineNumber: 168,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `p-3 rounded-xl text-sm leading-relaxed ${msg.role === "user" ? "bg-blue-500 text-white" : "bg-white border"}`,
                                                children: msg.role === "user" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: msg.content
                                                }, void 0, false, {
                                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                    lineNumber: 187,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "prose prose-sm max-w-none",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactMarkdown, {
                                                        remarkPlugins: [
                                                            remarkGfm
                                                        ],
                                                        children: msg.content
                                                    }, void 0, false, {
                                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                        lineNumber: 190,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                    lineNumber: 189,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                lineNumber: 179,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, msg.id != null ? `db-${msg.id}` : `ui-${msg.created_at ?? i}`, true, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 161,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 145,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Scrollbar"], {
                                orientation: "vertical",
                                className: "flex select-none touch-none p-0.5 bg-gray-100 transition-colors duration-150 ease-out hover:bg-gray-200",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Thumb"], {
                                    className: "flex-1 rounded-full bg-gray-400"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 204,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 200,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Corner"], {
                                className: "bg-gray-200"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 206,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 p-3 border-t bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan saya soal latihan dari topik yang dibahas"),
                                className: "px-3 py-2 rounded-lg text-sm bg-green-500 text-white hover:bg-green-600",
                                children: "+ Soal"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 211,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan flashcard untuk membantu saya belajar topik ini"),
                                className: "px-3 py-2 rounded-lg text-sm bg-purple-500 text-white hover:bg-purple-600",
                                children: "+ Flashcard"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 217,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan pertanyaan reflektif untuk membantu saya memahami topik ini lebih dalam"),
                                className: "px-3 py-2 rounded-lg text-sm bg-orange-500 text-white hover:bg-orange-600",
                                children: "+ Reflective Q"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 223,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 210,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "bg-gray-200 h-px w-full"
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 231,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: (e)=>{
                            e.preventDefault();
                            handleSendMessage();
                        },
                        className: "p-3 flex gap-2 border-t bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: "flex-1 border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-blue-400",
                                value: input,
                                placeholder: currentChatId ? "Jelasin apa kesulitanmu dalam belajar..." : "Klik + Chat Baru untuk memulai",
                                onChange: (e)=>setInput(e.target.value),
                                disabled: !currentChatId
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 241,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: !input.trim() || !currentChatId,
                                className: "px-4 py-2 rounded-lg border bg-blue-500 hover:bg-blue-600 text-white text-sm disabled:bg-gray-300 disabled:cursor-not-allowed",
                                children: "Kirim"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 248,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 234,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c9ec6ad3._.js.map