module.exports = [
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/store/chatStore.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// store/chatStore.ts
__turbopack_context__.s([
    "useChatStore",
    ()=>useChatStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$8_$40$types$2b$react$40$_012899d904cbc2a4f6aff4c4e49d4121$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/zustand@5.0.8_@types+react@_012899d904cbc2a4f6aff4c4e49d4121/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
const useChatStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$8_$40$types$2b$react$40$_012899d904cbc2a4f6aff4c4e49d4121$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        messages: [],
        chats: [],
        currentChatId: null,
        isLoading: false,
        setMessages: (messages)=>set({
                messages
            }),
        addMessage: (role, content)=>set((state)=>({
                    messages: [
                        ...state.messages,
                        {
                            role,
                            content,
                            created_at: new Date().toISOString()
                        }
                    ]
                })),
        setChats: (chats)=>set({
                chats
            }),
        setCurrentChatId: (chatId)=>set({
                currentChatId: chatId
            }),
        setLoading: (loading)=>set({
                isLoading: loading
            }),
        createNewChat: async (title = 'Chat Baru')=>{
            try {
                const res = await fetch('/api/chat/create', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        title
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Reload chats setelah membuat chat baru
                    await get().loadChats();
                    return data.chatId;
                }
                return null;
            } catch (error) {
                console.error('Error creating chat:', error);
                return null;
            }
        },
        loadMessages: async (chatId)=>{
            set({
                isLoading: true
            });
            try {
                const res = await fetch(`/api/chat/${chatId}/messages`);
                const data = await res.json();
                if (res.ok) {
                    // Transform data dari database ke format yang digunakan di UI
                    const messages = data.messages.map((msg)=>({
                            id: msg.id,
                            role: msg.role,
                            content: msg.content,
                            created_at: msg.created_at
                        }));
                    set({
                        messages,
                        currentChatId: chatId
                    });
                }
            } catch (error) {
                console.error('Error loading messages:', error);
            } finally{
                set({
                    isLoading: false
                });
            }
        },
        loadChats: async ()=>{
            try {
                const res = await fetch('/api/chat/list');
                const data = await res.json();
                if (res.ok) {
                    set({
                        chats: data.chats
                    });
                }
            } catch (error) {
                console.error('Error loading chats:', error);
            }
        },
        sendMessage: async (message, chatId)=>{
            // Tambahkan pesan user ke UI secara optimistic
            get().addMessage('user', message);
            try {
                const res = await fetch('/api/chat/gemini', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        message,
                        chatId
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Tambahkan response AI ke UI
                    get().addMessage('ai', data.reply);
                    // Reload chats untuk update last message
                    await get().loadChats();
                } else {
                    get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
                }
            } catch (error) {
                console.error('Error sending message:', error);
                get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
            }
        }
    }));
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs) <export default as minpath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minpath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
}),
"[externals]/node:process [external] (node:process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}),
"[externals]/node:process [external] (node:process, cjs) <export default as minproc>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "minproc",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:process [external] (node:process, cjs)");
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs) <export fileURLToPath as urlToPath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlToPath",
    ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__["fileURLToPath"]
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:url [external] (node:url, cjs)");
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/useGoogleCalendarToken.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGoogleCalendarToken",
    ()=>useGoogleCalendarToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
function useGoogleCalendarToken() {
    const [accessToken, setAccessToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const tokenClientRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Load token from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const storedToken = localStorage.getItem('google_access_token');
        if (storedToken) {
            console.log("Loaded access token from localStorage:", storedToken);
            setAccessToken(storedToken);
        }
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const initializeGoogleAPI = ()=>{
            if (!window.google) {
                console.warn("Google API belum dimuat di window.google");
                // Retry after a short delay
                setTimeout(initializeGoogleAPI, 1000);
                return;
            }
            console.log("Initializing Google OAuth token client");
            setIsLoading(false);
            tokenClientRef.current = window.google.accounts.oauth2.initTokenClient({
                client_id: ("TURBOPACK compile-time value", "571944083401-q8div1lspa33m0r646dv7b708uosqn88.apps.googleusercontent.com"),
                scope: "https://www.googleapis.com/auth/calendar.events",
                prompt: "",
                callback: (res)=>{
                    console.log("OAuth callback received:", res);
                    if (res.error) {
                        setError(res.error);
                        console.error("OAuth error:", res.error);
                        alert("OAuth Error: " + res.error);
                    } else {
                        console.log("Access token received:", res.access_token);
                        setAccessToken(res.access_token);
                        setError(null);
                        // Store token in localStorage
                        localStorage.setItem('google_access_token', res.access_token);
                        alert("✅ Google Calendar connected successfully!");
                        // Open Google Calendar after successful connection
                        window.open("https://calendar.google.com", "_blank");
                    }
                }
            });
        };
        initializeGoogleAPI();
    }, []);
    // Save token to localStorage whenever it changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (accessToken) {
            console.log("Saving access token to localStorage:", accessToken);
            localStorage.setItem('google_access_token', accessToken);
        } else {
            console.log("Removing access token from localStorage");
            localStorage.removeItem('google_access_token');
        }
    }, [
        accessToken
    ]);
    // ini fungsi yang dipanggil tombol
    const requestAccess = ()=>{
        console.log("Requesting access token...");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (!tokenClientRef.current) {
            setError("Token client not initialized");
            console.error("Token client not initialized");
            alert("Token client not initialized. Please try again later.");
            return;
        }
        tokenClientRef.current.requestAccessToken({
            prompt: ""
        });
    };
    return {
        accessToken,
        error,
        connect: requestAccess,
        isLoading
    };
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/createCalendarEvents.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/createCalendarEvent.ts
__turbopack_context__.s([
    "createCalendarEvent",
    ()=>createCalendarEvent
]);
async function createCalendarEvent(accessToken, event) {
    const res = await fetch("/api/chat/calendar", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            access_token: accessToken,
            ...event
        })
    });
    if (!res.ok) {
        throw new Error("Failed to create calendar event");
    }
    return res.json();
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CalendarConnectButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/useGoogleCalendarToken.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/createCalendarEvents.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function CalendarConnectButton() {
    const { accessToken, connect, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGoogleCalendarToken"])();
    // Debug accessToken in button component
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log("Access token in CalendarConnectButton:", accessToken);
    }, [
        accessToken
    ]);
    const handleConnect = ()=>{
        console.log("Connect button clicked");
        console.log("Google API available:", !!window.google);
        console.log("Client ID:", ("TURBOPACK compile-time value", "571944083401-q8div1lspa33m0r646dv7b708uosqn88.apps.googleusercontent.com"));
        if (!window.google) {
            alert("Google API not loaded yet. Please wait a moment and try again.");
            return;
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        connect();
    };
    const testCalendarEvent = async ()=>{
        if (!accessToken) {
            alert("Please connect to Google Calendar first!");
            return;
        }
        try {
            const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createCalendarEvent"])(accessToken, {
                title: "Test Event - StudyBuddy Integration",
                description: "Testing Google Calendar integration with StudyBuddy",
                start: new Date(Date.now() + 60000).toISOString(),
                end: new Date(Date.now() + 3600000).toISOString(),
                timezone: "Asia/Jakarta"
            });
            if (res.success) {
                alert("✅ Test event created successfully! Check your Google Calendar.");
            } else {
                alert("❌ Failed to create test event: " + res.error);
            }
        } catch (error) {
            alert("❌ Error creating test event: " + error.message);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleConnect,
                disabled: isLoading,
                className: `px-3 py-2 rounded-lg text-white text-sm font-medium transition-colors ${accessToken ? "bg-green-500 hover:bg-green-600" : isLoading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"}`,
                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4 animate-spin",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    className: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                    lineNumber: 73,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    className: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                    lineNumber: 74,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        "Loading..."
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 71,
                    columnNumber: 11
                }, this) : accessToken ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "currentColor",
                            viewBox: "0 0 20 20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                fillRule: "evenodd",
                                d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                clipRule: "evenodd"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                lineNumber: 81,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this),
                        "Connected"
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "currentColor",
                            viewBox: "0 0 20 20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1-1 1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                lineNumber: 88,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 87,
                            columnNumber: 13
                        }, this),
                        "Connect Calendar"
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 86,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            accessToken && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: testCalendarEvent,
                className: "px-3 py-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium transition-colors",
                children: "Test Event"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 96,
                columnNumber: 9
            }, this),
            accessToken && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-green-600 font-medium",
                children: "✓ Ready to create events"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 105,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-red-600 font-medium",
                children: [
                    "❌ ",
                    error
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 111,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/store/chatStore.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/@radix-ui+react-scroll-area_d9e216728f0e00b8dd2bc8f009ec26ca/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$separator$40$1_38f3ec12c6d53b641a7b970137cafd89$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/@radix-ui+react-separator@1_38f3ec12c6d53b641a7b970137cafd89/node_modules/@radix-ui/react-separator/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$react$2d$markdown$40$10$2e$1$2e$0_$40$types$2b$react$40$19$2e$1$2e$11_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/react-markdown@10.1.0_@types+react@19.1.11_react@19.1.0/node_modules/react-markdown/lib/index.js [app-ssr] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$remark$2d$gfm$40$4$2e$0$2e$1$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/remark-gfm@4.0.1/node_modules/remark-gfm/lib/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/useGoogleCalendarToken.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/createCalendarEvents.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$components$2f$CalendarConnectButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function Page() {
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [educationLevel, setEducationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("SD");
    const { messages, chats, currentChatId, isLoading, loadMessages, loadChats, createNewChat, sendMessage, setCurrentChatId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useChatStore"])();
    const { accessToken } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGoogleCalendarToken"])();
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Load chats saat komponen pertama kali dimuat
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        loadChats();
    }, [
        loadChats
    ]);
    // Auto scroll ke bawah saat ada pesan baru
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [
        messages
    ]);
    // Debug accessToken changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log("Access token in page.tsx:", accessToken);
        console.log("Access token from localStorage:", localStorage.getItem('google_access_token'));
    }, [
        accessToken
    ]);
    const handleSendMessage = async ()=>{
        if (!input.trim()) return;
        let chatId = currentChatId;
        // Jika belum ada chat yang aktif, wajib membuat/ memilih chat terlebih dahulu
        if (!chatId) {
            alert('Pilih atau buat chat terlebih dahulu');
            return;
        }
        // Tambahkan prefix level pendidikan ke pesan
        const educationPrefix = educationLevel ? `[Halo, aku di tingkat: ${educationLevel}]\n` : '';
        const messageWithEducation = educationPrefix + input;
        // Deteksi intent 
        if (input.toLowerCase().includes("buat jadwal")) {
            const token = accessToken || localStorage.getItem('google_access_token');
            if (!token) {
                alert("❌ Silakan connect ke Google Calendar terlebih dahulu dengan klik tombol 'Connect Google Calendar'");
                return;
            }
            // Parse title from user message - extract what's between "jadwal" and "pada"
            const titleMatch = input.match(/jadwal (.+?) pada/i);
            const eventTitle = titleMatch ? titleMatch[1].trim() : "Belajar bareng AI";
            // Parse date from user message
            const dateMatch = input.match(/tanggal (\d{1,2}) (\w+)/i) || input.match(/(\d{1,2}) (\w+)/i);
            let eventDate = "2025-09-05"; // default
            if (dateMatch) {
                const day = dateMatch[1].padStart(2, '0');
                const monthName = dateMatch[2].toLowerCase();
                const monthMap = {
                    'januari': '01',
                    'februari': '02',
                    'maret': '03',
                    'april': '04',
                    'mei': '05',
                    'juni': '06',
                    'juli': '07',
                    'agustus': '08',
                    'september': '09',
                    'oktober': '10',
                    'november': '11',
                    'desember': '12',
                    'january': '01',
                    'february': '02',
                    'march': '03',
                    'may': '05',
                    'june': '06',
                    'july': '07',
                    'august': '08',
                    'october': '10',
                    'december': '12'
                };
                if (monthMap[monthName]) {
                    eventDate = `2025-${monthMap[monthName]}-${day}`;
                }
            }
            // Parse time range from user message - handle both formats: "08.00 - 10.00" and "8 - 10"
            const timeMatch = input.match(/pukul (\d{1,2})(?:\.(\d{1,2}))? ?- ?(\d{1,2})(?:\.(\d{1,2}))?/i);
            let startTime = "10:00:00";
            let endTime = "11:00:00";
            if (timeMatch) {
                const startHour = timeMatch[1].padStart(2, '0');
                const startMinute = timeMatch[2] ? timeMatch[2].padStart(2, '0') : "00";
                const endHour = timeMatch[3].padStart(2, '0');
                const endMinute = timeMatch[4] ? timeMatch[4].padStart(2, '0') : "00";
                startTime = `${startHour}:${startMinute}:00`;
                endTime = `${endHour}:${endMinute}:00`;
            }
            try {
                const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createCalendarEvent"])(token, {
                    title: eventTitle,
                    description: input,
                    start: `${eventDate}T${startTime}+07:00`,
                    end: `${eventDate}T${endTime}+07:00`,
                    timezone: "Asia/Jakarta"
                });
                if (res.success) {
                    alert(`✅ Jadwal berhasil ditambahkan ke Google Calendar untuk tanggal ${eventDate} pukul ${startTime} - ${endTime}!`);
                } else {
                    alert("❌ Gagal menambahkan jadwal: " + res.error);
                }
            } catch (error) {
                alert("❌ Terjadi kesalahan saat menambahkan jadwal: " + error.message);
            }
        }
        // 2️⃣ Tetap kirim ke AI
        await sendMessage(messageWithEducation, chatId);
        setInput("");
    };
    const handleSelectChat = async (chatId)=>{
        setCurrentChatId(chatId);
        await loadMessages(chatId);
    };
    const handleNewChat = async ()=>{
        const chatId = await createNewChat();
        if (chatId) {
            setCurrentChatId(chatId);
            // Clear messages untuk chat baru
            __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$app$2f$store$2f$chatStore$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useChatStore"].setState({
                messages: []
            });
        }
    };
    const handleQuickMessage = async (message)=>{
        if (!currentChatId) {
            alert('Pilih atau buat chat terlebih dahulu');
            return;
        }
        // Tambahkan prefix level pendidikan ke pesan
        const educationPrefix = educationLevel ? `[Halo, aku di tingkat: ${educationLevel}]\n` : '';
        const messageWithEducation = educationPrefix + message;
        await sendMessage(messageWithEducation, currentChatId);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex w-full h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-64 border-r bg-gray-50 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-3 border-b",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleNewChat,
                            className: "w-full px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 text-sm",
                            children: "+ Chat Baru"
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                            className: "h-full w-full p-2",
                            children: chats.map((chat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    onClick: ()=>handleSelectChat(chat.id),
                                    className: `p-3 mb-2 rounded-lg cursor-pointer text-sm hover:bg-gray-100 ${currentChatId === chat.id ? 'bg-gray-200' : ''}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium truncate",
                                            children: chat.title
                                        }, void 0, false, {
                                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                            lineNumber: 189,
                                            columnNumber: 17
                                        }, this),
                                        chat.last_message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500 text-xs mt-1 truncate",
                                            children: chat.last_message
                                        }, void 0, false, {
                                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                            lineNumber: 191,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, chat.id, true, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 182,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                            lineNumber: 180,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between p-3 border-b",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/logo SB.png",
                                        alt: "StudyBuddy Logo",
                                        className: "h-9 w-11"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 206,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-blue-600",
                                        children: "StudyBuddy"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 207,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$components$2f$CalendarConnectButton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 209,
                                        columnNumber: 7
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 205,
                                columnNumber: 5
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: educationLevel,
                                onChange: (e)=>setEducationLevel(e.target.value),
                                className: "border rounded-md px-2 py-1 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SD",
                                        children: "SD"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 218,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SMP",
                                        children: "SMP"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 219,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "SMA",
                                        children: "SMA"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 220,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "Kuliah",
                                        children: "Kuliah"
                                    }, void 0, false, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 221,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 213,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 204,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "flex-1 overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                                ref: scrollRef,
                                className: "h-full w-full p-4 space-y-3",
                                style: {
                                    height: "100%"
                                },
                                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center text-gray-500",
                                    children: "Loading..."
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 233,
                                    columnNumber: 15
                                }, this) : messages.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center text-gray-500 mt-8",
                                    children: currentChatId ? "Belum ada pesan. Mulai percakapan!" : "Pilih chat atau buat chat baru untuk memulai"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 235,
                                    columnNumber: 15
                                }, this) : messages.map((msg, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `my-3 max-w-[80%] ${msg.role === "user" ? "ml-auto" : "mr-auto"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `text-md font-medium mb-1 ${msg.role === "user" ? "text-right text-blue-600" : "text-left text-gray-600"}`,
                                                children: msg.role === "user" ? "User" : "StudyBot"
                                            }, void 0, false, {
                                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                lineNumber: 250,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `p-3 rounded-xl text-sm leading-relaxed ${msg.role === "user" ? "bg-blue-500 text-white" : "bg-white border"}`,
                                                children: msg.role === "user" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: msg.content
                                                }, void 0, false, {
                                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                    lineNumber: 269,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "prose prose-sm max-w-none",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$react$2d$markdown$40$10$2e$1$2e$0_$40$types$2b$react$40$19$2e$1$2e$11_react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                                        remarkPlugins: [
                                                            __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$remark$2d$gfm$40$4$2e$0$2e$1$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
                                                        ],
                                                        children: msg.content
                                                    }, void 0, false, {
                                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                        lineNumber: 272,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                    lineNumber: 271,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                                lineNumber: 261,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, msg.id != null ? `db-${msg.id}` : `ui-${msg.created_at ?? i}`, true, {
                                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                        lineNumber: 243,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Scrollbar"], {
                                orientation: "vertical",
                                className: "flex select-none touch-none p-0.5 bg-gray-100 transition-colors duration-150 ease-out hover:bg-gray-200",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Thumb"], {
                                    className: "flex-1 rounded-full bg-gray-400"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                    lineNumber: 286,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 282,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$scroll$2d$area_d9e216728f0e00b8dd2bc8f009ec26ca$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Corner"], {
                                className: "bg-gray-200"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 288,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 p-3 border-t bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan saya soal latihan dari topik yang dibahas"),
                                className: "px-3 py-2 rounded-lg text-sm bg-green-500 text-white hover:bg-green-600",
                                children: "+ Soal"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 293,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan flashcard untuk membantu saya belajar topik ini"),
                                className: "px-3 py-2 rounded-lg text-sm bg-purple-500 text-white hover:bg-purple-600",
                                children: "+ Flashcard"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 299,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleQuickMessage("Buatkan pertanyaan reflektif untuk membantu saya memahami topik ini lebih dalam"),
                                className: "px-3 py-2 rounded-lg text-sm bg-orange-500 text-white hover:bg-orange-600",
                                children: "+ Reflective Q"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 305,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 292,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$separator$40$1_38f3ec12c6d53b641a7b970137cafd89$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                        className: "bg-gray-200 h-px w-full"
                    }, void 0, false, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 313,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: (e)=>{
                            e.preventDefault();
                            handleSendMessage();
                        },
                        className: "p-3 flex gap-2 border-t bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: "flex-1 border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-blue-400",
                                value: input,
                                placeholder: currentChatId ? "Jelasin apa kesulitanmu dalam belajar..." : "Klik + Chat Baru untuk memulai",
                                onChange: (e)=>setInput(e.target.value),
                                disabled: !currentChatId
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 323,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: !input.trim() || !currentChatId,
                                className: "px-4 py-2 rounded-lg border bg-blue-500 hover:bg-blue-600 text-white text-sm disabled:bg-gray-300 disabled:cursor-not-allowed",
                                children: "Kirim"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                        lineNumber: 316,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
                lineNumber: 202,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx",
        lineNumber: 167,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fba54cb8._.js.map