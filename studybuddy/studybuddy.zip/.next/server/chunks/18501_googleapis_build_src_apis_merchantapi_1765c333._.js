module.exports = [
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/accounts_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_accounts_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_accounts_v1;
(function(merchantapi_accounts_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('accounts_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        termsOfService;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
            this.termsOfService = new Resource$Termsofservice(this.context);
        }
    }
    merchantapi_accounts_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        autofeedSettings;
        automaticImprovements;
        businessIdentity;
        businessInfo;
        developerRegistration;
        emailPreferences;
        gbpAccounts;
        homepage;
        issues;
        omnichannelSettings;
        onlineReturnPolicies;
        programs;
        regions;
        relationships;
        services;
        shippingSettings;
        termsOfServiceAgreementStates;
        users;
        constructor(context){
            this.context = context;
            this.autofeedSettings = new Resource$Accounts$Autofeedsettings(this.context);
            this.automaticImprovements = new Resource$Accounts$Automaticimprovements(this.context);
            this.businessIdentity = new Resource$Accounts$Businessidentity(this.context);
            this.businessInfo = new Resource$Accounts$Businessinfo(this.context);
            this.developerRegistration = new Resource$Accounts$Developerregistration(this.context);
            this.emailPreferences = new Resource$Accounts$Emailpreferences(this.context);
            this.gbpAccounts = new Resource$Accounts$Gbpaccounts(this.context);
            this.homepage = new Resource$Accounts$Homepage(this.context);
            this.issues = new Resource$Accounts$Issues(this.context);
            this.omnichannelSettings = new Resource$Accounts$Omnichannelsettings(this.context);
            this.onlineReturnPolicies = new Resource$Accounts$Onlinereturnpolicies(this.context);
            this.programs = new Resource$Accounts$Programs(this.context);
            this.regions = new Resource$Accounts$Regions(this.context);
            this.relationships = new Resource$Accounts$Relationships(this.context);
            this.services = new Resource$Accounts$Services(this.context);
            this.shippingSettings = new Resource$Accounts$Shippingsettings(this.context);
            this.termsOfServiceAgreementStates = new Resource$Accounts$Termsofserviceagreementstates(this.context);
            this.users = new Resource$Accounts$Users(this.context);
        }
        createAndConfigure(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/accounts:createAndConfigure').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/accounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        listSubaccounts(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+provider}:listSubaccounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'provider'
                ],
                pathParams: [
                    'provider'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Autofeedsettings {
        context;
        constructor(context){
            this.context = context;
        }
        getAutofeedSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateAutofeedSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Autofeedsettings = Resource$Accounts$Autofeedsettings;
    class Resource$Accounts$Automaticimprovements {
        context;
        constructor(context){
            this.context = context;
        }
        getAutomaticImprovements(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateAutomaticImprovements(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Automaticimprovements = Resource$Accounts$Automaticimprovements;
    class Resource$Accounts$Businessidentity {
        context;
        constructor(context){
            this.context = context;
        }
        getBusinessIdentity(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateBusinessIdentity(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Businessidentity = Resource$Accounts$Businessidentity;
    class Resource$Accounts$Businessinfo {
        context;
        constructor(context){
            this.context = context;
        }
        getBusinessInfo(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateBusinessInfo(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Businessinfo = Resource$Accounts$Businessinfo;
    class Resource$Accounts$Developerregistration {
        context;
        constructor(context){
            this.context = context;
        }
        getDeveloperRegistration(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        registerGcp(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:registerGcp').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        unregisterGcp(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:unregisterGcp').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Developerregistration = Resource$Accounts$Developerregistration;
    class Resource$Accounts$Emailpreferences {
        context;
        constructor(context){
            this.context = context;
        }
        getEmailPreferences(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateEmailPreferences(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Emailpreferences = Resource$Accounts$Emailpreferences;
    class Resource$Accounts$Gbpaccounts {
        context;
        constructor(context){
            this.context = context;
        }
        linkGbpAccount(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/gbpAccounts:linkGbpAccount').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/gbpAccounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Gbpaccounts = Resource$Accounts$Gbpaccounts;
    class Resource$Accounts$Homepage {
        context;
        constructor(context){
            this.context = context;
        }
        claim(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:claim').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        getHomepage(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        unclaim(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:unclaim').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateHomepage(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Homepage = Resource$Accounts$Homepage;
    class Resource$Accounts$Issues {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/issues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Issues = Resource$Accounts$Issues;
    class Resource$Accounts$Omnichannelsettings {
        context;
        lfpProviders;
        constructor(context){
            this.context = context;
            this.lfpProviders = new Resource$Accounts$Omnichannelsettings$Lfpproviders(this.context);
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/omnichannelSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/omnichannelSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        requestInventoryVerification(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:requestInventoryVerification').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Omnichannelsettings = Resource$Accounts$Omnichannelsettings;
    class Resource$Accounts$Omnichannelsettings$Lfpproviders {
        context;
        constructor(context){
            this.context = context;
        }
        find(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/lfpProviders:find').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        linkLfpProvider(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:linkLfpProvider').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Omnichannelsettings$Lfpproviders = Resource$Accounts$Omnichannelsettings$Lfpproviders;
    class Resource$Accounts$Onlinereturnpolicies {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/onlineReturnPolicies').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/onlineReturnPolicies').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Onlinereturnpolicies = Resource$Accounts$Onlinereturnpolicies;
    class Resource$Accounts$Programs {
        context;
        checkoutSettings;
        constructor(context){
            this.context = context;
            this.checkoutSettings = new Resource$Accounts$Programs$Checkoutsettings(this.context);
        }
        disable(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:disable').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        enable(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:enable').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/programs').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Programs = Resource$Accounts$Programs;
    class Resource$Accounts$Programs$Checkoutsettings {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/checkoutSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        deleteCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        getCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Programs$Checkoutsettings = Resource$Accounts$Programs$Checkoutsettings;
    class Resource$Accounts$Regions {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/regions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/regions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Regions = Resource$Accounts$Regions;
    class Resource$Accounts$Relationships {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/relationships').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Relationships = Resource$Accounts$Relationships;
    class Resource$Accounts$Services {
        context;
        constructor(context){
            this.context = context;
        }
        approve(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:approve').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/services').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        propose(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/services:propose').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        reject(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:reject').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Services = Resource$Accounts$Services;
    class Resource$Accounts$Shippingsettings {
        context;
        constructor(context){
            this.context = context;
        }
        getShippingSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/shippingSettings:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Shippingsettings = Resource$Accounts$Shippingsettings;
    class Resource$Accounts$Termsofserviceagreementstates {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        retrieveForApplication(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/termsOfServiceAgreementStates:retrieveForApplication').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Termsofserviceagreementstates = Resource$Accounts$Termsofserviceagreementstates;
    class Resource$Accounts$Users {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/users').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+parent}/users').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Accounts$Users = Resource$Accounts$Users;
    class Resource$Termsofservice {
        context;
        constructor(context){
            this.context = context;
        }
        accept(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}:accept').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        retrieveLatest(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1/termsOfService:retrieveLatest').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1.Resource$Termsofservice = Resource$Termsofservice;
})(merchantapi_accounts_v1 || (exports.merchantapi_accounts_v1 = merchantapi_accounts_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/accounts_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_accounts_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_accounts_v1beta;
(function(merchantapi_accounts_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('accounts_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        termsOfService;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
            this.termsOfService = new Resource$Termsofservice(this.context);
        }
    }
    merchantapi_accounts_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        autofeedSettings;
        automaticImprovements;
        businessIdentity;
        businessInfo;
        developerRegistration;
        emailPreferences;
        gbpAccounts;
        homepage;
        issues;
        omnichannelSettings;
        onlineReturnPolicies;
        programs;
        regions;
        relationships;
        services;
        shippingSettings;
        termsOfServiceAgreementStates;
        users;
        constructor(context){
            this.context = context;
            this.autofeedSettings = new Resource$Accounts$Autofeedsettings(this.context);
            this.automaticImprovements = new Resource$Accounts$Automaticimprovements(this.context);
            this.businessIdentity = new Resource$Accounts$Businessidentity(this.context);
            this.businessInfo = new Resource$Accounts$Businessinfo(this.context);
            this.developerRegistration = new Resource$Accounts$Developerregistration(this.context);
            this.emailPreferences = new Resource$Accounts$Emailpreferences(this.context);
            this.gbpAccounts = new Resource$Accounts$Gbpaccounts(this.context);
            this.homepage = new Resource$Accounts$Homepage(this.context);
            this.issues = new Resource$Accounts$Issues(this.context);
            this.omnichannelSettings = new Resource$Accounts$Omnichannelsettings(this.context);
            this.onlineReturnPolicies = new Resource$Accounts$Onlinereturnpolicies(this.context);
            this.programs = new Resource$Accounts$Programs(this.context);
            this.regions = new Resource$Accounts$Regions(this.context);
            this.relationships = new Resource$Accounts$Relationships(this.context);
            this.services = new Resource$Accounts$Services(this.context);
            this.shippingSettings = new Resource$Accounts$Shippingsettings(this.context);
            this.termsOfServiceAgreementStates = new Resource$Accounts$Termsofserviceagreementstates(this.context);
            this.users = new Resource$Accounts$Users(this.context);
        }
        createAndConfigure(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/accounts:createAndConfigure').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/accounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        listSubaccounts(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+provider}:listSubaccounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'provider'
                ],
                pathParams: [
                    'provider'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Autofeedsettings {
        context;
        constructor(context){
            this.context = context;
        }
        getAutofeedSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateAutofeedSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Autofeedsettings = Resource$Accounts$Autofeedsettings;
    class Resource$Accounts$Automaticimprovements {
        context;
        constructor(context){
            this.context = context;
        }
        getAutomaticImprovements(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateAutomaticImprovements(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Automaticimprovements = Resource$Accounts$Automaticimprovements;
    class Resource$Accounts$Businessidentity {
        context;
        constructor(context){
            this.context = context;
        }
        getBusinessIdentity(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateBusinessIdentity(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Businessidentity = Resource$Accounts$Businessidentity;
    class Resource$Accounts$Businessinfo {
        context;
        constructor(context){
            this.context = context;
        }
        getBusinessInfo(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateBusinessInfo(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Businessinfo = Resource$Accounts$Businessinfo;
    class Resource$Accounts$Developerregistration {
        context;
        constructor(context){
            this.context = context;
        }
        getDeveloperRegistration(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        registerGcp(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:registerGcp').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        unregisterGcp(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:unregisterGcp').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Developerregistration = Resource$Accounts$Developerregistration;
    class Resource$Accounts$Emailpreferences {
        context;
        constructor(context){
            this.context = context;
        }
        getEmailPreferences(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateEmailPreferences(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Emailpreferences = Resource$Accounts$Emailpreferences;
    class Resource$Accounts$Gbpaccounts {
        context;
        constructor(context){
            this.context = context;
        }
        linkGbpAccount(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/gbpAccounts:linkGbpAccount').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/gbpAccounts').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Gbpaccounts = Resource$Accounts$Gbpaccounts;
    class Resource$Accounts$Homepage {
        context;
        constructor(context){
            this.context = context;
        }
        claim(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:claim').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        getHomepage(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        unclaim(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:unclaim').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateHomepage(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Homepage = Resource$Accounts$Homepage;
    class Resource$Accounts$Issues {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/issues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Issues = Resource$Accounts$Issues;
    class Resource$Accounts$Omnichannelsettings {
        context;
        lfpProviders;
        constructor(context){
            this.context = context;
            this.lfpProviders = new Resource$Accounts$Omnichannelsettings$Lfpproviders(this.context);
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/omnichannelSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/omnichannelSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        requestInventoryVerification(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:requestInventoryVerification').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Omnichannelsettings = Resource$Accounts$Omnichannelsettings;
    class Resource$Accounts$Omnichannelsettings$Lfpproviders {
        context;
        constructor(context){
            this.context = context;
        }
        find(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/lfpProviders:find').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        linkLfpProvider(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:linkLfpProvider').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Omnichannelsettings$Lfpproviders = Resource$Accounts$Omnichannelsettings$Lfpproviders;
    class Resource$Accounts$Onlinereturnpolicies {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/onlineReturnPolicies').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/onlineReturnPolicies').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Onlinereturnpolicies = Resource$Accounts$Onlinereturnpolicies;
    class Resource$Accounts$Programs {
        context;
        checkoutSettings;
        constructor(context){
            this.context = context;
            this.checkoutSettings = new Resource$Accounts$Programs$Checkoutsettings(this.context);
        }
        disable(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:disable').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        enable(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:enable').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/programs').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Programs = Resource$Accounts$Programs;
    class Resource$Accounts$Programs$Checkoutsettings {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/checkoutSettings').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        deleteCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        getCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        updateCheckoutSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Programs$Checkoutsettings = Resource$Accounts$Programs$Checkoutsettings;
    class Resource$Accounts$Regions {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/regions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/regions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Regions = Resource$Accounts$Regions;
    class Resource$Accounts$Relationships {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/relationships').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Relationships = Resource$Accounts$Relationships;
    class Resource$Accounts$Services {
        context;
        constructor(context){
            this.context = context;
        }
        approve(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:approve').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/services').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        propose(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/services:propose').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        reject(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:reject').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Services = Resource$Accounts$Services;
    class Resource$Accounts$Shippingsettings {
        context;
        constructor(context){
            this.context = context;
        }
        getShippingSettings(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/shippingSettings:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Shippingsettings = Resource$Accounts$Shippingsettings;
    class Resource$Accounts$Termsofserviceagreementstates {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        retrieveForApplication(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/termsOfServiceAgreementStates:retrieveForApplication').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Termsofserviceagreementstates = Resource$Accounts$Termsofserviceagreementstates;
    class Resource$Accounts$Users {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/users').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+parent}/users').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Accounts$Users = Resource$Accounts$Users;
    class Resource$Termsofservice {
        context;
        constructor(context){
            this.context = context;
        }
        accept(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}:accept').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        retrieveLatest(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/accounts/v1beta/termsOfService:retrieveLatest').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [],
                pathParams: [],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_accounts_v1beta.Resource$Termsofservice = Resource$Termsofservice;
})(merchantapi_accounts_v1beta || (exports.merchantapi_accounts_v1beta = merchantapi_accounts_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/conversions_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_conversions_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_conversions_v1;
(function(merchantapi_conversions_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('conversions_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_conversions_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        conversionSources;
        constructor(context){
            this.context = context;
            this.conversionSources = new Resource$Accounts$Conversionsources(this.context);
        }
    }
    merchantapi_conversions_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Conversionsources {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+parent}/conversionSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+parent}/conversionSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        undelete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1/{+name}:undelete').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_conversions_v1.Resource$Accounts$Conversionsources = Resource$Accounts$Conversionsources;
})(merchantapi_conversions_v1 || (exports.merchantapi_conversions_v1 = merchantapi_conversions_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/conversions_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_conversions_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_conversions_v1beta;
(function(merchantapi_conversions_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('conversions_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_conversions_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        conversionSources;
        constructor(context){
            this.context = context;
            this.conversionSources = new Resource$Accounts$Conversionsources(this.context);
        }
    }
    merchantapi_conversions_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Conversionsources {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+parent}/conversionSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+parent}/conversionSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        undelete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/conversions/v1beta/{+name}:undelete').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_conversions_v1beta.Resource$Accounts$Conversionsources = Resource$Accounts$Conversionsources;
})(merchantapi_conversions_v1beta || (exports.merchantapi_conversions_v1beta = merchantapi_conversions_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/datasources_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_datasources_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_datasources_v1;
(function(merchantapi_datasources_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('datasources_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_datasources_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        dataSources;
        constructor(context){
            this.context = context;
            this.dataSources = new Resource$Accounts$Datasources(this.context);
        }
    }
    merchantapi_datasources_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Datasources {
        context;
        fileUploads;
        constructor(context){
            this.context = context;
            this.fileUploads = new Resource$Accounts$Datasources$Fileuploads(this.context);
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+parent}/dataSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        fetch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+name}:fetch').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+parent}/dataSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_datasources_v1.Resource$Accounts$Datasources = Resource$Accounts$Datasources;
    class Resource$Accounts$Datasources$Fileuploads {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_datasources_v1.Resource$Accounts$Datasources$Fileuploads = Resource$Accounts$Datasources$Fileuploads;
})(merchantapi_datasources_v1 || (exports.merchantapi_datasources_v1 = merchantapi_datasources_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/datasources_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_datasources_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_datasources_v1beta;
(function(merchantapi_datasources_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('datasources_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_datasources_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        dataSources;
        constructor(context){
            this.context = context;
            this.dataSources = new Resource$Accounts$Datasources(this.context);
        }
    }
    merchantapi_datasources_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Datasources {
        context;
        fileUploads;
        constructor(context){
            this.context = context;
            this.fileUploads = new Resource$Accounts$Datasources$Fileuploads(this.context);
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+parent}/dataSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        fetch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+name}:fetch').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+parent}/dataSources').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_datasources_v1beta.Resource$Accounts$Datasources = Resource$Accounts$Datasources;
    class Resource$Accounts$Datasources$Fileuploads {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/datasources/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_datasources_v1beta.Resource$Accounts$Datasources$Fileuploads = Resource$Accounts$Datasources$Fileuploads;
})(merchantapi_datasources_v1beta || (exports.merchantapi_datasources_v1beta = merchantapi_datasources_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/inventories_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_inventories_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_inventories_v1;
(function(merchantapi_inventories_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('inventories_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_inventories_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        products;
        constructor(context){
            this.context = context;
            this.products = new Resource$Accounts$Products(this.context);
        }
    }
    merchantapi_inventories_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Products {
        context;
        localInventories;
        regionalInventories;
        constructor(context){
            this.context = context;
            this.localInventories = new Resource$Accounts$Products$Localinventories(this.context);
            this.regionalInventories = new Resource$Accounts$Products$Regionalinventories(this.context);
        }
    }
    merchantapi_inventories_v1.Resource$Accounts$Products = Resource$Accounts$Products;
    class Resource$Accounts$Products$Localinventories {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+parent}/localInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+parent}/localInventories').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_inventories_v1.Resource$Accounts$Products$Localinventories = Resource$Accounts$Products$Localinventories;
    class Resource$Accounts$Products$Regionalinventories {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+parent}/regionalInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1/{+parent}/regionalInventories').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_inventories_v1.Resource$Accounts$Products$Regionalinventories = Resource$Accounts$Products$Regionalinventories;
})(merchantapi_inventories_v1 || (exports.merchantapi_inventories_v1 = merchantapi_inventories_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/inventories_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_inventories_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_inventories_v1beta;
(function(merchantapi_inventories_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('inventories_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_inventories_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        products;
        constructor(context){
            this.context = context;
            this.products = new Resource$Accounts$Products(this.context);
        }
    }
    merchantapi_inventories_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Products {
        context;
        localInventories;
        regionalInventories;
        constructor(context){
            this.context = context;
            this.localInventories = new Resource$Accounts$Products$Localinventories(this.context);
            this.regionalInventories = new Resource$Accounts$Products$Regionalinventories(this.context);
        }
    }
    merchantapi_inventories_v1beta.Resource$Accounts$Products = Resource$Accounts$Products;
    class Resource$Accounts$Products$Localinventories {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+parent}/localInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+parent}/localInventories').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_inventories_v1beta.Resource$Accounts$Products$Localinventories = Resource$Accounts$Products$Localinventories;
    class Resource$Accounts$Products$Regionalinventories {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+parent}/regionalInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/inventories/v1beta/{+parent}/regionalInventories').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_inventories_v1beta.Resource$Accounts$Products$Regionalinventories = Resource$Accounts$Products$Regionalinventories;
})(merchantapi_inventories_v1beta || (exports.merchantapi_inventories_v1beta = merchantapi_inventories_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/issueresolution_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_issueresolution_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_issueresolution_v1;
(function(merchantapi_issueresolution_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('issueresolution_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        issueresolution;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
            this.issueresolution = new Resource$Issueresolution(this.context);
        }
    }
    merchantapi_issueresolution_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        aggregateProductStatuses;
        constructor(context){
            this.context = context;
            this.aggregateProductStatuses = new Resource$Accounts$Aggregateproductstatuses(this.context);
        }
    }
    merchantapi_issueresolution_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Aggregateproductstatuses {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1/{+parent}/aggregateProductStatuses').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_issueresolution_v1.Resource$Accounts$Aggregateproductstatuses = Resource$Accounts$Aggregateproductstatuses;
    class Resource$Issueresolution {
        context;
        constructor(context){
            this.context = context;
        }
        renderaccountissues(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1/{+name}:renderaccountissues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        renderproductissues(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1/{+name}:renderproductissues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        triggeraction(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1/{+name}:triggeraction').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_issueresolution_v1.Resource$Issueresolution = Resource$Issueresolution;
})(merchantapi_issueresolution_v1 || (exports.merchantapi_issueresolution_v1 = merchantapi_issueresolution_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/issueresolution_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_issueresolution_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_issueresolution_v1beta;
(function(merchantapi_issueresolution_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('issueresolution_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        issueresolution;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
            this.issueresolution = new Resource$Issueresolution(this.context);
        }
    }
    merchantapi_issueresolution_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        aggregateProductStatuses;
        constructor(context){
            this.context = context;
            this.aggregateProductStatuses = new Resource$Accounts$Aggregateproductstatuses(this.context);
        }
    }
    merchantapi_issueresolution_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Aggregateproductstatuses {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1beta/{+parent}/aggregateProductStatuses').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_issueresolution_v1beta.Resource$Accounts$Aggregateproductstatuses = Resource$Accounts$Aggregateproductstatuses;
    class Resource$Issueresolution {
        context;
        constructor(context){
            this.context = context;
        }
        renderaccountissues(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1beta/{+name}:renderaccountissues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        renderproductissues(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1beta/{+name}:renderproductissues').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        triggeraction(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/issueresolution/v1beta/{+name}:triggeraction').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_issueresolution_v1beta.Resource$Issueresolution = Resource$Issueresolution;
})(merchantapi_issueresolution_v1beta || (exports.merchantapi_issueresolution_v1beta = merchantapi_issueresolution_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/lfp_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_lfp_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_lfp_v1;
(function(merchantapi_lfp_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('lfp_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_lfp_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        lfpInventories;
        lfpMerchantStates;
        lfpSales;
        lfpStores;
        constructor(context){
            this.context = context;
            this.lfpInventories = new Resource$Accounts$Lfpinventories(this.context);
            this.lfpMerchantStates = new Resource$Accounts$Lfpmerchantstates(this.context);
            this.lfpSales = new Resource$Accounts$Lfpsales(this.context);
            this.lfpStores = new Resource$Accounts$Lfpstores(this.context);
        }
    }
    merchantapi_lfp_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Lfpinventories {
        context;
        constructor(context){
            this.context = context;
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+parent}/lfpInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1.Resource$Accounts$Lfpinventories = Resource$Accounts$Lfpinventories;
    class Resource$Accounts$Lfpmerchantstates {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1.Resource$Accounts$Lfpmerchantstates = Resource$Accounts$Lfpmerchantstates;
    class Resource$Accounts$Lfpsales {
        context;
        constructor(context){
            this.context = context;
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+parent}/lfpSales:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1.Resource$Accounts$Lfpsales = Resource$Accounts$Lfpsales;
    class Resource$Accounts$Lfpstores {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+parent}/lfpStores:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1/{+parent}/lfpStores').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1.Resource$Accounts$Lfpstores = Resource$Accounts$Lfpstores;
})(merchantapi_lfp_v1 || (exports.merchantapi_lfp_v1 = merchantapi_lfp_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/lfp_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_lfp_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_lfp_v1beta;
(function(merchantapi_lfp_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('lfp_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_lfp_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        lfpInventories;
        lfpMerchantStates;
        lfpSales;
        lfpStores;
        constructor(context){
            this.context = context;
            this.lfpInventories = new Resource$Accounts$Lfpinventories(this.context);
            this.lfpMerchantStates = new Resource$Accounts$Lfpmerchantstates(this.context);
            this.lfpSales = new Resource$Accounts$Lfpsales(this.context);
            this.lfpStores = new Resource$Accounts$Lfpstores(this.context);
        }
    }
    merchantapi_lfp_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Lfpinventories {
        context;
        constructor(context){
            this.context = context;
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+parent}/lfpInventories:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1beta.Resource$Accounts$Lfpinventories = Resource$Accounts$Lfpinventories;
    class Resource$Accounts$Lfpmerchantstates {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1beta.Resource$Accounts$Lfpmerchantstates = Resource$Accounts$Lfpmerchantstates;
    class Resource$Accounts$Lfpsales {
        context;
        constructor(context){
            this.context = context;
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+parent}/lfpSales:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1beta.Resource$Accounts$Lfpsales = Resource$Accounts$Lfpsales;
    class Resource$Accounts$Lfpstores {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+parent}/lfpStores:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/lfp/v1beta/{+parent}/lfpStores').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_lfp_v1beta.Resource$Accounts$Lfpstores = Resource$Accounts$Lfpstores;
})(merchantapi_lfp_v1beta || (exports.merchantapi_lfp_v1beta = merchantapi_lfp_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/notifications_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_notifications_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_notifications_v1;
(function(merchantapi_notifications_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('notifications_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_notifications_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        notificationsubscriptions;
        constructor(context){
            this.context = context;
            this.notificationsubscriptions = new Resource$Accounts$Notificationsubscriptions(this.context);
        }
    }
    merchantapi_notifications_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Notificationsubscriptions {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1/{+parent}/notificationsubscriptions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1/{+parent}/notificationsubscriptions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_notifications_v1.Resource$Accounts$Notificationsubscriptions = Resource$Accounts$Notificationsubscriptions;
})(merchantapi_notifications_v1 || (exports.merchantapi_notifications_v1 = merchantapi_notifications_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/notifications_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_notifications_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_notifications_v1beta;
(function(merchantapi_notifications_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('notifications_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_notifications_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        notificationsubscriptions;
        constructor(context){
            this.context = context;
            this.notificationsubscriptions = new Resource$Accounts$Notificationsubscriptions(this.context);
        }
    }
    merchantapi_notifications_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Notificationsubscriptions {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1beta/{+parent}/notificationsubscriptions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1beta/{+parent}/notificationsubscriptions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/notifications/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_notifications_v1beta.Resource$Accounts$Notificationsubscriptions = Resource$Accounts$Notificationsubscriptions;
})(merchantapi_notifications_v1beta || (exports.merchantapi_notifications_v1beta = merchantapi_notifications_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/ordertracking_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_ordertracking_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_ordertracking_v1;
(function(merchantapi_ordertracking_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('ordertracking_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_ordertracking_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        orderTrackingSignals;
        constructor(context){
            this.context = context;
            this.orderTrackingSignals = new Resource$Accounts$Ordertrackingsignals(this.context);
        }
    }
    merchantapi_ordertracking_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Ordertrackingsignals {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/ordertracking/v1/{+parent}/orderTrackingSignals').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_ordertracking_v1.Resource$Accounts$Ordertrackingsignals = Resource$Accounts$Ordertrackingsignals;
})(merchantapi_ordertracking_v1 || (exports.merchantapi_ordertracking_v1 = merchantapi_ordertracking_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/ordertracking_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_ordertracking_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_ordertracking_v1beta;
(function(merchantapi_ordertracking_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('ordertracking_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_ordertracking_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        orderTrackingSignals;
        constructor(context){
            this.context = context;
            this.orderTrackingSignals = new Resource$Accounts$Ordertrackingsignals(this.context);
        }
    }
    merchantapi_ordertracking_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Ordertrackingsignals {
        context;
        constructor(context){
            this.context = context;
        }
        create(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/ordertracking/v1beta/{+parent}/orderTrackingSignals').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_ordertracking_v1beta.Resource$Accounts$Ordertrackingsignals = Resource$Accounts$Ordertrackingsignals;
})(merchantapi_ordertracking_v1beta || (exports.merchantapi_ordertracking_v1beta = merchantapi_ordertracking_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/products_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_products_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_products_v1;
(function(merchantapi_products_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('products_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_products_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        productInputs;
        products;
        constructor(context){
            this.context = context;
            this.productInputs = new Resource$Accounts$Productinputs(this.context);
            this.products = new Resource$Accounts$Products(this.context);
        }
    }
    merchantapi_products_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Productinputs {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1/{+parent}/productInputs:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_products_v1.Resource$Accounts$Productinputs = Resource$Accounts$Productinputs;
    class Resource$Accounts$Products {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1/{+parent}/products').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_products_v1.Resource$Accounts$Products = Resource$Accounts$Products;
})(merchantapi_products_v1 || (exports.merchantapi_products_v1 = merchantapi_products_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/products_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_products_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_products_v1beta;
(function(merchantapi_products_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('products_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_products_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        productInputs;
        products;
        constructor(context){
            this.context = context;
            this.productInputs = new Resource$Accounts$Productinputs(this.context);
            this.products = new Resource$Accounts$Products(this.context);
        }
    }
    merchantapi_products_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Productinputs {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1beta/{+parent}/productInputs:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        patch(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'PATCH',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_products_v1beta.Resource$Accounts$Productinputs = Resource$Accounts$Productinputs;
    class Resource$Accounts$Products {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/products/v1beta/{+parent}/products').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_products_v1beta.Resource$Accounts$Products = Resource$Accounts$Products;
})(merchantapi_products_v1beta || (exports.merchantapi_products_v1beta = merchantapi_products_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/promotions_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_promotions_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_promotions_v1;
(function(merchantapi_promotions_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('promotions_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_promotions_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        promotions;
        constructor(context){
            this.context = context;
            this.promotions = new Resource$Accounts$Promotions(this.context);
        }
    }
    merchantapi_promotions_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Promotions {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1/{+parent}/promotions:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1/{+parent}/promotions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_promotions_v1.Resource$Accounts$Promotions = Resource$Accounts$Promotions;
})(merchantapi_promotions_v1 || (exports.merchantapi_promotions_v1 = merchantapi_promotions_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/promotions_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_promotions_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_promotions_v1beta;
(function(merchantapi_promotions_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('promotions_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_promotions_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        promotions;
        constructor(context){
            this.context = context;
            this.promotions = new Resource$Accounts$Promotions(this.context);
        }
    }
    merchantapi_promotions_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Promotions {
        context;
        constructor(context){
            this.context = context;
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1beta/{+parent}/promotions:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/promotions/v1beta/{+parent}/promotions').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_promotions_v1beta.Resource$Accounts$Promotions = Resource$Accounts$Promotions;
})(merchantapi_promotions_v1beta || (exports.merchantapi_promotions_v1beta = merchantapi_promotions_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/quota_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_quota_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_quota_v1;
(function(merchantapi_quota_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('quota_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_quota_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        quotas;
        constructor(context){
            this.context = context;
            this.quotas = new Resource$Accounts$Quotas(this.context);
        }
    }
    merchantapi_quota_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Quotas {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/quota/v1/{+parent}/quotas').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_quota_v1.Resource$Accounts$Quotas = Resource$Accounts$Quotas;
})(merchantapi_quota_v1 || (exports.merchantapi_quota_v1 = merchantapi_quota_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/quota_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_quota_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_quota_v1beta;
(function(merchantapi_quota_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('quota_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_quota_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        quotas;
        constructor(context){
            this.context = context;
            this.quotas = new Resource$Accounts$Quotas(this.context);
        }
    }
    merchantapi_quota_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Quotas {
        context;
        constructor(context){
            this.context = context;
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/quota/v1beta/{+parent}/quotas').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_quota_v1beta.Resource$Accounts$Quotas = Resource$Accounts$Quotas;
})(merchantapi_quota_v1beta || (exports.merchantapi_quota_v1beta = merchantapi_quota_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reports_v1.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_reports_v1 = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_reports_v1;
(function(merchantapi_reports_v1) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('reports_v1');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_reports_v1.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        reports;
        constructor(context){
            this.context = context;
            this.reports = new Resource$Accounts$Reports(this.context);
        }
    }
    merchantapi_reports_v1.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Reports {
        context;
        constructor(context){
            this.context = context;
        }
        search(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reports/v1/{+parent}/reports:search').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_reports_v1.Resource$Accounts$Reports = Resource$Accounts$Reports;
})(merchantapi_reports_v1 || (exports.merchantapi_reports_v1 = merchantapi_reports_v1 = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reports_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_reports_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_reports_v1beta;
(function(merchantapi_reports_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('reports_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_reports_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        reports;
        constructor(context){
            this.context = context;
            this.reports = new Resource$Accounts$Reports(this.context);
        }
    }
    merchantapi_reports_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Reports {
        context;
        constructor(context){
            this.context = context;
        }
        search(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reports/v1beta/{+parent}/reports:search').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_reports_v1beta.Resource$Accounts$Reports = Resource$Accounts$Reports;
})(merchantapi_reports_v1beta || (exports.merchantapi_reports_v1beta = merchantapi_reports_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reviews_v1beta.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.merchantapi_reviews_v1beta = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable @typescript-eslint/no-unused-vars */ /* eslint-disable @typescript-eslint/no-empty-interface */ /* eslint-disable @typescript-eslint/no-namespace */ /* eslint-disable no-irregular-whitespace */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
var merchantapi_reviews_v1beta;
(function(merchantapi_reviews_v1beta) {
    /**
     * Merchant API
     *
     * Programmatically manage your Merchant Center Accounts.
     *
     * @example
     * ```js
     * const {google} = require('googleapis');
     * const merchantapi = google.merchantapi('reviews_v1beta');
     * ```
     */ class Merchantapi {
        context;
        accounts;
        constructor(options, google){
            this.context = {
                _options: options || {},
                google
            };
            this.accounts = new Resource$Accounts(this.context);
        }
    }
    merchantapi_reviews_v1beta.Merchantapi = Merchantapi;
    class Resource$Accounts {
        context;
        merchantReviews;
        productReviews;
        constructor(context){
            this.context = context;
            this.merchantReviews = new Resource$Accounts$Merchantreviews(this.context);
            this.productReviews = new Resource$Accounts$Productreviews(this.context);
        }
    }
    merchantapi_reviews_v1beta.Resource$Accounts = Resource$Accounts;
    class Resource$Accounts$Merchantreviews {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+parent}/merchantReviews:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+parent}/merchantReviews').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_reviews_v1beta.Resource$Accounts$Merchantreviews = Resource$Accounts$Merchantreviews;
    class Resource$Accounts$Productreviews {
        context;
        constructor(context){
            this.context = context;
        }
        delete(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'DELETE',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        get(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+name}').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'name'
                ],
                pathParams: [
                    'name'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        insert(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+parent}/productReviews:insert').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'POST',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
        list(paramsOrCallback, optionsOrCallback, callback) {
            let params = paramsOrCallback || {};
            let options = optionsOrCallback || {};
            if (typeof paramsOrCallback === 'function') {
                callback = paramsOrCallback;
                params = {};
                options = {};
            }
            if (typeof optionsOrCallback === 'function') {
                callback = optionsOrCallback;
                options = {};
            }
            const rootUrl = options.rootUrl || 'https://merchantapi.googleapis.com/';
            const parameters = {
                options: Object.assign({
                    url: (rootUrl + '/reviews/v1beta/{+parent}/productReviews').replace(/([^:]\/)\/+/g, '$1'),
                    method: 'GET',
                    apiVersion: ''
                }, options),
                params,
                requiredParams: [
                    'parent'
                ],
                pathParams: [
                    'parent'
                ],
                context: this.context
            };
            if (callback) {
                (0, googleapis_common_1.createAPIRequest)(parameters, callback);
            } else {
                return (0, googleapis_common_1.createAPIRequest)(parameters);
            }
        }
    }
    merchantapi_reviews_v1beta.Resource$Accounts$Productreviews = Resource$Accounts$Productreviews;
})(merchantapi_reviews_v1beta || (exports.merchantapi_reviews_v1beta = merchantapi_reviews_v1beta = {}));
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright 2020 Google LLC
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AuthPlus = exports.merchantapi_reviews_v1beta = exports.merchantapi_reports_v1beta = exports.merchantapi_reports_v1 = exports.merchantapi_quota_v1beta = exports.merchantapi_quota_v1 = exports.merchantapi_promotions_v1beta = exports.merchantapi_promotions_v1 = exports.merchantapi_products_v1beta = exports.merchantapi_products_v1 = exports.merchantapi_ordertracking_v1beta = exports.merchantapi_ordertracking_v1 = exports.merchantapi_notifications_v1beta = exports.merchantapi_notifications_v1 = exports.merchantapi_lfp_v1beta = exports.merchantapi_lfp_v1 = exports.merchantapi_issueresolution_v1beta = exports.merchantapi_issueresolution_v1 = exports.merchantapi_inventories_v1beta = exports.merchantapi_inventories_v1 = exports.merchantapi_datasources_v1beta = exports.merchantapi_datasources_v1 = exports.merchantapi_conversions_v1beta = exports.merchantapi_conversions_v1 = exports.merchantapi_accounts_v1beta = exports.merchantapi_accounts_v1 = exports.auth = exports.VERSIONS = void 0;
exports.merchantapi = merchantapi;
/*! THIS FILE IS AUTO-GENERATED */ const googleapis_common_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
const accounts_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/accounts_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_accounts_v1", {
    enumerable: true,
    get: function() {
        return accounts_v1_1.merchantapi_accounts_v1;
    }
});
const accounts_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/accounts_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_accounts_v1beta", {
    enumerable: true,
    get: function() {
        return accounts_v1beta_1.merchantapi_accounts_v1beta;
    }
});
const conversions_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/conversions_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_conversions_v1", {
    enumerable: true,
    get: function() {
        return conversions_v1_1.merchantapi_conversions_v1;
    }
});
const conversions_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/conversions_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_conversions_v1beta", {
    enumerable: true,
    get: function() {
        return conversions_v1beta_1.merchantapi_conversions_v1beta;
    }
});
const datasources_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/datasources_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_datasources_v1", {
    enumerable: true,
    get: function() {
        return datasources_v1_1.merchantapi_datasources_v1;
    }
});
const datasources_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/datasources_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_datasources_v1beta", {
    enumerable: true,
    get: function() {
        return datasources_v1beta_1.merchantapi_datasources_v1beta;
    }
});
const inventories_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/inventories_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_inventories_v1", {
    enumerable: true,
    get: function() {
        return inventories_v1_1.merchantapi_inventories_v1;
    }
});
const inventories_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/inventories_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_inventories_v1beta", {
    enumerable: true,
    get: function() {
        return inventories_v1beta_1.merchantapi_inventories_v1beta;
    }
});
const issueresolution_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/issueresolution_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_issueresolution_v1", {
    enumerable: true,
    get: function() {
        return issueresolution_v1_1.merchantapi_issueresolution_v1;
    }
});
const issueresolution_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/issueresolution_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_issueresolution_v1beta", {
    enumerable: true,
    get: function() {
        return issueresolution_v1beta_1.merchantapi_issueresolution_v1beta;
    }
});
const lfp_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/lfp_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_lfp_v1", {
    enumerable: true,
    get: function() {
        return lfp_v1_1.merchantapi_lfp_v1;
    }
});
const lfp_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/lfp_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_lfp_v1beta", {
    enumerable: true,
    get: function() {
        return lfp_v1beta_1.merchantapi_lfp_v1beta;
    }
});
const notifications_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/notifications_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_notifications_v1", {
    enumerable: true,
    get: function() {
        return notifications_v1_1.merchantapi_notifications_v1;
    }
});
const notifications_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/notifications_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_notifications_v1beta", {
    enumerable: true,
    get: function() {
        return notifications_v1beta_1.merchantapi_notifications_v1beta;
    }
});
const ordertracking_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/ordertracking_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_ordertracking_v1", {
    enumerable: true,
    get: function() {
        return ordertracking_v1_1.merchantapi_ordertracking_v1;
    }
});
const ordertracking_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/ordertracking_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_ordertracking_v1beta", {
    enumerable: true,
    get: function() {
        return ordertracking_v1beta_1.merchantapi_ordertracking_v1beta;
    }
});
const products_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/products_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_products_v1", {
    enumerable: true,
    get: function() {
        return products_v1_1.merchantapi_products_v1;
    }
});
const products_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/products_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_products_v1beta", {
    enumerable: true,
    get: function() {
        return products_v1beta_1.merchantapi_products_v1beta;
    }
});
const promotions_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/promotions_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_promotions_v1", {
    enumerable: true,
    get: function() {
        return promotions_v1_1.merchantapi_promotions_v1;
    }
});
const promotions_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/promotions_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_promotions_v1beta", {
    enumerable: true,
    get: function() {
        return promotions_v1beta_1.merchantapi_promotions_v1beta;
    }
});
const quota_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/quota_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_quota_v1", {
    enumerable: true,
    get: function() {
        return quota_v1_1.merchantapi_quota_v1;
    }
});
const quota_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/quota_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_quota_v1beta", {
    enumerable: true,
    get: function() {
        return quota_v1beta_1.merchantapi_quota_v1beta;
    }
});
const reports_v1_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reports_v1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_reports_v1", {
    enumerable: true,
    get: function() {
        return reports_v1_1.merchantapi_reports_v1;
    }
});
const reports_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reports_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_reports_v1beta", {
    enumerable: true,
    get: function() {
        return reports_v1beta_1.merchantapi_reports_v1beta;
    }
});
const reviews_v1beta_1 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis@159.0.0/node_modules/googleapis/build/src/apis/merchantapi/reviews_v1beta.js [app-route] (ecmascript)");
Object.defineProperty(exports, "merchantapi_reviews_v1beta", {
    enumerable: true,
    get: function() {
        return reviews_v1beta_1.merchantapi_reviews_v1beta;
    }
});
exports.VERSIONS = {
    accounts_v1: accounts_v1_1.merchantapi_accounts_v1.Merchantapi,
    accounts_v1beta: accounts_v1beta_1.merchantapi_accounts_v1beta.Merchantapi,
    conversions_v1: conversions_v1_1.merchantapi_conversions_v1.Merchantapi,
    conversions_v1beta: conversions_v1beta_1.merchantapi_conversions_v1beta.Merchantapi,
    datasources_v1: datasources_v1_1.merchantapi_datasources_v1.Merchantapi,
    datasources_v1beta: datasources_v1beta_1.merchantapi_datasources_v1beta.Merchantapi,
    inventories_v1: inventories_v1_1.merchantapi_inventories_v1.Merchantapi,
    inventories_v1beta: inventories_v1beta_1.merchantapi_inventories_v1beta.Merchantapi,
    issueresolution_v1: issueresolution_v1_1.merchantapi_issueresolution_v1.Merchantapi,
    issueresolution_v1beta: issueresolution_v1beta_1.merchantapi_issueresolution_v1beta.Merchantapi,
    lfp_v1: lfp_v1_1.merchantapi_lfp_v1.Merchantapi,
    lfp_v1beta: lfp_v1beta_1.merchantapi_lfp_v1beta.Merchantapi,
    notifications_v1: notifications_v1_1.merchantapi_notifications_v1.Merchantapi,
    notifications_v1beta: notifications_v1beta_1.merchantapi_notifications_v1beta.Merchantapi,
    ordertracking_v1: ordertracking_v1_1.merchantapi_ordertracking_v1.Merchantapi,
    ordertracking_v1beta: ordertracking_v1beta_1.merchantapi_ordertracking_v1beta.Merchantapi,
    products_v1: products_v1_1.merchantapi_products_v1.Merchantapi,
    products_v1beta: products_v1beta_1.merchantapi_products_v1beta.Merchantapi,
    promotions_v1: promotions_v1_1.merchantapi_promotions_v1.Merchantapi,
    promotions_v1beta: promotions_v1beta_1.merchantapi_promotions_v1beta.Merchantapi,
    quota_v1: quota_v1_1.merchantapi_quota_v1.Merchantapi,
    quota_v1beta: quota_v1beta_1.merchantapi_quota_v1beta.Merchantapi,
    reports_v1: reports_v1_1.merchantapi_reports_v1.Merchantapi,
    reports_v1beta: reports_v1beta_1.merchantapi_reports_v1beta.Merchantapi,
    reviews_v1beta: reviews_v1beta_1.merchantapi_reviews_v1beta.Merchantapi
};
function merchantapi(versionOrOptions) {
    return (0, googleapis_common_1.getAPI)('merchantapi', versionOrOptions, exports.VERSIONS, this);
}
const auth = new googleapis_common_1.AuthPlus();
exports.auth = auth;
var googleapis_common_2 = __turbopack_context__.r("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/googleapis-common@8.0.0/node_modules/googleapis-common/build/src/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "AuthPlus", {
    enumerable: true,
    get: function() {
        return googleapis_common_2.AuthPlus;
    }
});
}),
];

//# sourceMappingURL=18501_googleapis_build_src_apis_merchantapi_1765c333._.js.map