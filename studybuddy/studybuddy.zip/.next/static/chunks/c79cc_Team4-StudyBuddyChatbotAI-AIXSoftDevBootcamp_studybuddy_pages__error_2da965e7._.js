(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1365e_next_dist_compiled_next-devtools_index_53cdb8b7.js",
  "static/chunks/1365e_next_dist_compiled_577c8467._.js",
  "static/chunks/1365e_next_dist_shared_lib_a5dbaf08._.js",
  "static/chunks/1365e_next_dist_client_f9896f0a._.js",
  "static/chunks/1365e_next_dist_6096650c._.js",
  "static/chunks/1365e_next_error_c53d308c.js",
  "static/chunks/[next]_entry_page-loader_ts_61fa96bb._.js",
  "static/chunks/887f2_react-dom_ee9a018d._.js",
  "static/chunks/bd54d__pnpm_a3608d83._.js",
  "static/chunks/[root-of-the-server]__ca0d98ee._.js"
],
    source: "entry"
});
