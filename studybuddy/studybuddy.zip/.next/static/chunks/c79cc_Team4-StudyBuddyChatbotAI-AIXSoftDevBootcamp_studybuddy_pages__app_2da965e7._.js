(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1365e_next_dist_compiled_next-devtools_index_53cdb8b7.js",
  "static/chunks/1365e_next_dist_compiled_577c8467._.js",
  "static/chunks/1365e_next_dist_shared_lib_14a5ecfe._.js",
  "static/chunks/1365e_next_dist_client_f9896f0a._.js",
  "static/chunks/1365e_next_dist_3a159df6._.js",
  "static/chunks/1365e_next_app_dc1d24ba.js",
  "static/chunks/[next]_entry_page-loader_ts_e0e949c0._.js",
  "static/chunks/887f2_react-dom_ee9a018d._.js",
  "static/chunks/bd54d__pnpm_a3608d83._.js",
  "static/chunks/[root-of-the-server]__d3e2ab8a._.js"
],
    source: "entry"
});
