__turbopack_load_page_chunks__("/_app", [
  "static/chunks/1365e_next_dist_compiled_next-devtools_index_53cdb8b7.js",
  "static/chunks/1365e_next_dist_compiled_577c8467._.js",
  "static/chunks/1365e_next_dist_shared_lib_14a5ecfe._.js",
  "static/chunks/1365e_next_dist_client_f9896f0a._.js",
  "static/chunks/1365e_next_dist_3a159df6._.js",
  "static/chunks/1365e_next_app_dc1d24ba.js",
  "static/chunks/[next]_entry_page-loader_ts_e0e949c0._.js",
  "static/chunks/887f2_react-dom_ee9a018d._.js",
  "static/chunks/bd54d__pnpm_a3608d83._.js",
  "static/chunks/[root-of-the-server]__d3e2ab8a._.js",
  "static/chunks/c79cc_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_pages__app_2da965e7._.js",
  "static/chunks/7dc55_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_pages__app_1b868947._.js"
])
