(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/51c69_property-information_df1c51f2._.js",
  "static/chunks/25d67_micromark_dev_lib_7c0201aa._.js",
  "static/chunks/da388_micromark-core-commonmark_dev_lib_2b1c3023._.js",
  "static/chunks/bd54d__pnpm_7a09f1de._.js",
  "static/chunks/c79cc_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_src_app_570f0482._.js"
],
    source: "dynamic"
});
