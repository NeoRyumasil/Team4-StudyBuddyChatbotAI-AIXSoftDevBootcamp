(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bd54d_b9834f98._.js",
  "static/chunks/c79cc_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_src_app_570f0482._.js"
],
    source: "dynamic"
});
