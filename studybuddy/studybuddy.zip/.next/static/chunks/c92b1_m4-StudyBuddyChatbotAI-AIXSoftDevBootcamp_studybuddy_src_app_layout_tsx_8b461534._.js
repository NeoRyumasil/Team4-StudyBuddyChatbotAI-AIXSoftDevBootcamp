(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__478a95d9._.css",
  "static/chunks/1365e_next_dist_client_1c070583._.js"
],
    source: "dynamic"
});
