(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/store/chatStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// store/chatStore.ts
__turbopack_context__.s([
    "useChatStore",
    ()=>useChatStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$8_$40$types$2b$react$40$_012899d904cbc2a4f6aff4c4e49d4121$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/zustand@5.0.8_@types+react@_012899d904cbc2a4f6aff4c4e49d4121/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useChatStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$8_$40$types$2b$react$40$_012899d904cbc2a4f6aff4c4e49d4121$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        messages: [],
        chats: [],
        currentChatId: null,
        isLoading: false,
        setMessages: (messages)=>set({
                messages
            }),
        addMessage: (role, content)=>set((state)=>({
                    messages: [
                        ...state.messages,
                        {
                            role,
                            content,
                            created_at: new Date().toISOString()
                        }
                    ]
                })),
        setChats: (chats)=>set({
                chats
            }),
        setCurrentChatId: (chatId)=>set({
                currentChatId: chatId
            }),
        setLoading: (loading)=>set({
                isLoading: loading
            }),
        createNewChat: async function() {
            let title = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 'Chat Baru';
            try {
                const res = await fetch('/api/chat/create', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        title
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Reload chats setelah membuat chat baru
                    await get().loadChats();
                    return data.chatId;
                }
                return null;
            } catch (error) {
                console.error('Error creating chat:', error);
                return null;
            }
        },
        loadMessages: async (chatId)=>{
            set({
                isLoading: true
            });
            try {
                const res = await fetch("/api/chat/".concat(chatId, "/messages"));
                const data = await res.json();
                if (res.ok) {
                    // Transform data dari database ke format yang digunakan di UI
                    const messages = data.messages.map((msg)=>({
                            id: msg.id,
                            role: msg.role,
                            content: msg.content,
                            created_at: msg.created_at
                        }));
                    set({
                        messages,
                        currentChatId: chatId
                    });
                }
            } catch (error) {
                console.error('Error loading messages:', error);
            } finally{
                set({
                    isLoading: false
                });
            }
        },
        loadChats: async ()=>{
            try {
                const res = await fetch('/api/chat/list');
                const data = await res.json();
                if (res.ok) {
                    set({
                        chats: data.chats
                    });
                }
            } catch (error) {
                console.error('Error loading chats:', error);
            }
        },
        sendMessage: async (message, chatId)=>{
            // Tambahkan pesan user ke UI secara optimistic
            get().addMessage('user', message);
            try {
                const res = await fetch('/api/chat/gemini', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        message,
                        chatId
                    })
                });
                const data = await res.json();
                if (res.ok) {
                    // Tambahkan response AI ke UI
                    get().addMessage('ai', data.reply);
                    // Reload chats untuk update last message
                    await get().loadChats();
                } else {
                    get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
                }
            } catch (error) {
                console.error('Error sending message:', error);
                get().addMessage('ai', 'Terjadi kesalahan saat menghubungi AI.');
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/useGoogleCalendarToken.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGoogleCalendarToken",
    ()=>useGoogleCalendarToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useGoogleCalendarToken() {
    _s();
    const [accessToken, setAccessToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const tokenClientRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGoogleCalendarToken.useEffect": ()=>{
            const initializeGoogleAPI = {
                "useGoogleCalendarToken.useEffect.initializeGoogleAPI": ()=>{
                    if (!window.google) {
                        console.warn("Google API belum dimuat di window.google");
                        // Retry after a short delay
                        setTimeout(initializeGoogleAPI, 1000);
                        return;
                    }
                    console.log("Initializing Google OAuth token client");
                    setIsLoading(false);
                    tokenClientRef.current = window.google.accounts.oauth2.initTokenClient({
                        client_id: ("TURBOPACK compile-time value", "571944083401-q8div1lspa33m0r646dv7b708uosqn88.apps.googleusercontent.com"),
                        scope: "https://www.googleapis.com/auth/calendar.events",
                        prompt: "consent",
                        callback: {
                            "useGoogleCalendarToken.useEffect.initializeGoogleAPI": (res)=>{
                                console.log("OAuth callback received:", res);
                                if (res.error) {
                                    setError(res.error);
                                    console.error("OAuth error:", res.error);
                                    alert("OAuth Error: " + res.error);
                                } else {
                                    console.log("Access token received:", res.access_token);
                                    setAccessToken(res.access_token);
                                    setError(null);
                                    alert("✅ Google Calendar connected successfully!");
                                    // Open Google Calendar after successful connection
                                    window.open("https://calendar.google.com", "_blank");
                                }
                            }
                        }["useGoogleCalendarToken.useEffect.initializeGoogleAPI"]
                    });
                }
            }["useGoogleCalendarToken.useEffect.initializeGoogleAPI"];
            initializeGoogleAPI();
        }
    }["useGoogleCalendarToken.useEffect"], []);
    // ini fungsi yang dipanggil tombol
    const requestAccess = ()=>{
        var _tokenClientRef_current;
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        (_tokenClientRef_current = tokenClientRef.current) === null || _tokenClientRef_current === void 0 ? void 0 : _tokenClientRef_current.requestAccessToken({
            prompt: "consent"
        });
    };
    return {
        accessToken,
        error,
        connect: requestAccess,
        isLoading
    };
}
_s(useGoogleCalendarToken, "uP4I+RJfClTW4myYhK6vBfM9Q5M=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/createCalendarEvents.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/createCalendarEvent.ts
__turbopack_context__.s([
    "createCalendarEvent",
    ()=>createCalendarEvent
]);
async function createCalendarEvent(accessToken, event) {
    const res = await fetch("/api/chat/calendar", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            access_token: accessToken,
            ...event
        })
    });
    if (!res.ok) {
        throw new Error("Failed to create calendar event");
    }
    return res.json();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CalendarConnectButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/useGoogleCalendarToken.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/lib/createCalendarEvents.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function CalendarConnectButton() {
    _s();
    const { accessToken, connect, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGoogleCalendarToken"])();
    const handleConnect = ()=>{
        console.log("Connect button clicked");
        console.log("Google API available:", !!window.google);
        console.log("Client ID:", ("TURBOPACK compile-time value", "571944083401-q8div1lspa33m0r646dv7b708uosqn88.apps.googleusercontent.com"));
        if (!window.google) {
            alert("Google API not loaded yet. Please wait a moment and try again.");
            return;
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        connect();
    };
    const testCalendarEvent = async ()=>{
        if (!accessToken) {
            alert("Please connect to Google Calendar first!");
            return;
        }
        try {
            const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$createCalendarEvents$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCalendarEvent"])(accessToken, {
                title: "Test Event - StudyBuddy Integration",
                description: "Testing Google Calendar integration with StudyBuddy",
                start: new Date(Date.now() + 60000).toISOString(),
                end: new Date(Date.now() + 3600000).toISOString(),
                timezone: "Asia/Jakarta"
            });
            if (res.success) {
                alert("✅ Test event created successfully! Check your Google Calendar.");
            } else {
                alert("❌ Failed to create test event: " + res.error);
            }
        } catch (error) {
            alert("❌ Error creating test event: " + error.message);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleConnect,
                disabled: isLoading,
                className: "px-3 py-2 rounded-lg text-white text-sm font-medium transition-colors ".concat(accessToken ? "bg-green-500 hover:bg-green-600" : isLoading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"),
                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4 animate-spin",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    className: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                    lineNumber: 69,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    className: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                }, void 0, false, {
                                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 68,
                            columnNumber: 13
                        }, this),
                        "Loading..."
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 67,
                    columnNumber: 11
                }, this) : accessToken ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "currentColor",
                            viewBox: "0 0 20 20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                fillRule: "evenodd",
                                d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                clipRule: "evenodd"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                lineNumber: 77,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 76,
                            columnNumber: 13
                        }, this),
                        "Connected"
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 75,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "currentColor",
                            viewBox: "0 0 20 20",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                d: "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"
                            }, void 0, false, {
                                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                                lineNumber: 84,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                            lineNumber: 83,
                            columnNumber: 13
                        }, this),
                        "Connect Calendar"
                    ]
                }, void 0, true, {
                    fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                    lineNumber: 82,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            accessToken && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: testCalendarEvent,
                className: "px-3 py-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium transition-colors",
                children: "Test Event"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 92,
                columnNumber: 9
            }, this),
            accessToken && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-green-600 font-medium",
                children: "✓ Ready to create events"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 101,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-red-600 font-medium",
                children: [
                    "❌ ",
                    error
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
                lineNumber: 107,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/CalendarConnectButton.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(CalendarConnectButton, "imAY9g24B3zL9r/I5i8C44kedxQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$src$2f$lib$2f$useGoogleCalendarToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGoogleCalendarToken"]
    ];
});
_c = CalendarConnectButton;
var _c;
__turbopack_context__.k.register(_c, "CalendarConnectButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/TestEnv.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TestEnv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/node_modules/.pnpm/next@15.5.0_@opentelemetry+_b911f251051713a29755274992b22490/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function TestEnv() {
    console.log("TestEnv - Google Client ID:", ("TURBOPACK compile-time value", "571944083401-q8div1lspa33m0r646dv7b708uosqn88.apps.googleusercontent.com"));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 bg-yellow-100 border border-yellow-300 rounded",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "font-bold",
                children: "Environment Test"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/TestEnv.tsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "Google Client ID: ",
                    ("TURBOPACK compile-time truthy", 1) ? "✅ Set" : "TURBOPACK unreachable"
                ]
            }, void 0, true, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/TestEnv.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$StudyBuddy$2f$Team4$2d$StudyBuddyChatbotAI$2d$AIXSoftDevBootcamp$2f$studybuddy$2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$0_$40$opentelemetry$2b$_b911f251051713a29755274992b22490$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Check browser console for more details"
            }, void 0, false, {
                fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/TestEnv.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/components/TestEnv.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = TestEnv;
var _c;
__turbopack_context__.k.register(_c, "TestEnv");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/StudyBuddy/Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp/studybuddy/src/app/page.tsx'\n\nUnexpected token. Did you mean `{'}'}` or `&rbrace;`?");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
]);

//# sourceMappingURL=StudyBuddy_Team4-StudyBuddyChatbotAI-AIXSoftDevBootcamp_studybuddy_src_7a19a2a2._.js.map