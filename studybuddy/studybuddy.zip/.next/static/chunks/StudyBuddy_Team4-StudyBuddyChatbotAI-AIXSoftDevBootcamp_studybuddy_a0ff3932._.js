(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_76ac2649._.js",
  "static/chunks/1365e_next_dist_compiled_react-dom_e3801902._.js",
  "static/chunks/1365e_next_dist_compiled_next-devtools_index_bcc0a00f.js",
  "static/chunks/1365e_next_dist_compiled_632c2c03._.js",
  "static/chunks/1365e_next_dist_client_32793aa9._.js",
  "static/chunks/1365e_next_dist_de4883a6._.js",
  "static/chunks/c3895_@swc_helpers_cjs_6ac9f14c._.js"
],
    source: "entry"
});
